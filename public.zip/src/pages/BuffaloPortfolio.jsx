import React from "react";
import { ArrowRight } from "lucide-react";

import { Icon } from "@iconify/react";
const plans = [
    {
        title: "1 Buffalo",
        subtitle: "Perfect for first-time agri-investors",
        price: "₹1,50,000",
        roi: "11 % P.A",
        features: [
            "Monthly payouts",
            "Individual animal tracking",
            "Monthly Health Reports",
            "Full Ownership Documentation",
            "Farm Visit Access",
        ],
    },
    {
        title: "5 Buffalo",
        subtitle: "Best For Small or growing Investors",
        price: "₹7,50,000",
        roi: "12 % P.A",
        features: [
            "Monthly payouts",
            "Portfolio Dashboard access",
            "Bi-weekly health reports",
            "Priority Farm visit scheduling",
            "Dedicated support contact",
            "Full Ownership Documentation",
        ],
    },
    {
        title: "10 Buffalo",
        subtitle: "Perfect for first-time agri-investors",
        price: "₹15,00,000",
        roi: "13 % P.A",
        features: [
            "Monthly payouts",
            "Premium Portfolio dashboard",
            "Weekly health updates",
            "Full Ownership Documentation",
            "Unlimited Farm Visits",
            "Dedicated Account Manager",
        ],
    },
];

const BuffaloPortfolio = () => {
    return (
        <div className="w-full py-16 px-4 sm:px-6 md:px-10 flex flex-col items-center bg-white font-sans">
            {/* Header */}
            <div className="text-center mb-12 max-w-4xl">
                <span className="text-xs inline-block bg-[#2D461D] text-white px-3 py-1 rounded-full mb-3">
                    Investment Plans
                </span>
                <h2 className="text-3xl sm:text-4xl md:text-5xl font-bold text-gray-900">
                    <span className="text-[#A9FF67]">Choose</span> Your Buffalo{" "}
                    <span className="text-[#A9FF67]">Portfolio</span>
                </h2>
                <p className="text-gray-700 mt-3 text-sm sm:text-base">
                    Transparent, scalable investment options with documented ownership and monthly returns.
                </p>
            </div>

            {/* Cards */}
            <div className="w-full max-w-[75%] flex flex-col md:flex-row gap-6 items-stretch">
                {plans.map((plan, index) => (
                    <div
                        key={index}
                        className="flex-1 bg-[#C9FF9F66] rounded-xl p-6 md:p-8 flex flex-col justify-between shadow-md"
                    >
                        {/* Header */}
                        <div>
                            <h3 className="text-[#2D461D] text-2xl font-goodly">{plan.title}</h3>
                            <p className="text-sm text-[#2D461D] mt-1">{plan.subtitle}</p>

                            <div className="mt-4">
                                <p className="text-2xl text-[#2D461D] font-semibold">{plan.price}</p>
                                <p className="text-md mt-1 text-[#2D461D]">{plan.roi}</p>
                            </div>

                            {/* Features */}
                            <div className="mt-4 bg-[#2D461D] text-[#FEFAE5] rounded-lg p-4 h-[89%] space-y-2">
                                {plan.features.map((feat, i) => (
                                    <div key={i} className="flex items-center  gap-2 text-sm">
                                        <span className="w-4 h-4 bg-[#A9FF67] flex items-center rounded rounded-full justify-center">
                                            <h1 className="text-[#2D461D] text-sm"  >✓</h1>
                                            {/* <Icon icon="material-symbols-light:check-circle-rounded" className="text-pink-500 text-sm" /> */}
                                        </span>
                                        <span>{feat}</span>
                                    </div>
                                ))}
                            </div>
                        </div>

                        {/* CTA */}
                        <button className="mt-24 w-full flex items-center justify-center gap-2 bg-[#2D461D] text-[#A9FF67] py-3 rounded-full hover:bg-[#3F6324] transition-colors">
                            Invest Now <ArrowRight size={16} />
                        </button>
                    </div>
                ))}
            </div>

        </div>
    );
};

export default BuffaloPortfolio;
