import React from 'react'
import Home from './Home'
import About from './About'
import Footer from './Footer'
import Contact from './Contact'
import ThreeStepStartEarning from './ThreeStepStartEarning'
import BuffaloPortfolio from './BuffaloPortfolio'

const Hero = () => {
    return <div div className='h-screen'>

        <Home />
        <About />
        <ThreeStepStartEarning />
        <BuffaloPortfolio />
        <div className='ml-20 mr-20 mt-5'>
            <Contact />
        </div>
        <div className='ml-10 mr-10 mt-5'>
            <Footer />
        </div>
    </div>
}

export default Hero