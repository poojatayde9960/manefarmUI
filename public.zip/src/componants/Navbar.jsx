import React from "react";
import logo from "/logo.png";

const Navbar = () => {
    return (
        <nav className="w-full px-4 sm:px-6 md:px-1 md:py-9 py-3 flex flex-col md:flex-row items-center justify-between gap-4 md:gap-0 font-manrope">

            {/* Left Logo */}
            <img
                src={logo}
                alt="logo"
                className="w-12 h-12 sm:w-16 sm:h-16 object-contain"
            />

            {/* Center Nav Items Box */}
            <div
                className="flex flex-wrap justify-center md:flex-nowrap items-center gap-2 sm:gap-4 md:gap-10 px-4 py-2 md:py-3 w-full md:w-[34%] rounded-xl"
                style={{
                    background: "#2D461D",
                    boxShadow:
                        "0px 0px 6.1px 1px rgba(169,255,103,0.3) inset",
                }}
            >
                <button className="px-2 sm:px-4 py-1 rounded-md text-xs sm:text-sm font-medium"
                    style={{ background: "#A9FF67", color: "#2D461D" }}>
                    Home
                </button>

                {["Benefits", "Plans", "About", "Gallery"].map((item) => (
                    <button
                        key={item}
                        className="text-[#A9FF67] text-xs sm:text-sm font-medium hover:opacity-80 transition"
                    >
                        {item}
                    </button>
                ))}
            </div>

            {/* Right Side Buttons */}
            <div className="flex flex-wrap md:flex-nowrap items-center gap-2 sm:gap-4 md:gap-4">
                {/* Login Button */}
                <button
                    className="px-6 sm:px-10 py-2 sm:py-3 rounded-xl text-xs sm:text-sm text-[#A9FF67] font-medium"
                    style={{
                        background: "rgba(45,70,29,0.8)",
                        boxShadow: "0px 0px 6.1px 1px #A9FF67 inset",
                    }}
                >
                    Login
                </button>

                {/* Contact Us Button */}
                <button
                    className="px-4 sm:px-6 py-2 sm:py-3 rounded-xl text-xs sm:text-sm text-[#2D461D] font-medium"
                    style={{ background: "#A9FF67" }}
                >
                    Contact Us
                </button>
            </div>
        </nav>
    );
};

export default Navbar;
